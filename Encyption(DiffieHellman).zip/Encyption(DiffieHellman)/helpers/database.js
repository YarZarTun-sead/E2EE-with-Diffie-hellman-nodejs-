var mysql = require('mysql');
var pool  = mysql.createPool({
	connectionLimit : 100,
    host: 'localhost',
    user: 'root',
    password : 'root',
	port: 3306,
	database:'test_diffiehellman',
	dateStrings: 'date',
	multipleStatements: true,
	charset : 'utf8mb4'
});

var getConnection = function(callback) {
    pool.getConnection(function(err, connection) {
		
        callback(err, connection);
    });
};

exports.getConnection = getConnection;