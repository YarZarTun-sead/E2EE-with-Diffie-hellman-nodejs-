var mysql = require('mysql');
var pool  = mysql.createPool({
	connectionLimit : 100,
    host: 'localhost',//192.168.100.100 //127.0.0.1
    user: 'root',
    password : 'root',//@dminl0ckd0wn //root//stc_win_user65535
	port: 3306,
	database:'test_diffiehellman',
	dateStrings: 'date',
	multipleStatements: true,
	charset : 'utf8mb4'
});

var getConnection = function(callback) {
    pool.getConnection(function(err, connection) {
		
        callback(err, connection);
    });
};

exports.getConnection = getConnection;