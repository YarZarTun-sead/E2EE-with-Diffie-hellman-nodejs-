var express = require('express');
var router = express.Router();
var user_model = require('../models/user_model');


router.get('/', function(req, res) {
	console.log("Start");
	res.render('index');
});

router.post('/request_user', function(req, res) {
	// console.log(req.body);
	user_model.requestUser(req.body,function (err,result) {
		if(!err){
			res.render('message',result);
		}else{
			res.send(err);
		}
	})
	
});

module.exports = router;