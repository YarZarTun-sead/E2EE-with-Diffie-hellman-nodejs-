var db = require('../helpers/database');
const crypto = require('crypto');
const assert = require('assert');

exports.requestUser = function(user, cb)
{	
	// For Diffie hellman in server
	// console.log(user);
	// console.log("requestUser");
	// Generate Alice's keys...
	const alice = crypto.createDiffieHellman(64);	
	const aliceKey = alice.generateKeys();
	// console.log("aliceKey");
	// console.log(aliceKey);
	var alice_public = alice.getPublicKey();
	var alice_private = alice.getPrivateKey();
	console.log("alice_public");
	console.log(alice_public);
	console.log("alice_private");
	console.log(alice_private);
	// console.log("get prime")
	// console.log(alice.getPrime());
	// console.log("get generator");
	// console.log(alice.getGenerator());

	// Generate Bob's keys...
	const bob = crypto.createDiffieHellman(alice.getPrime(), alice.getGenerator());	
	const bobKey = bob.generateKeys();
	// console.log("bobKey");
	// console.log(bobKey);
	var bob_public = bob.getPublicKey();
	var bob_private = bob.getPrivateKey();
	console.log("bob_public");
	console.log(bob_public);
	console.log("bob_private");
	console.log(bob_private);

	// Exchange and generate the secret...
	const aliceSecret = alice.computeSecret(bobKey);
	const bobSecret = bob.computeSecret(aliceKey);

	console.log("aliceSecret")
	console.log(aliceSecret)
	console.log("bobSecret")
	console.log(bobSecret)
	var aliceSharedSecret = aliceSecret;
	var bobSharedSecret = bobSecret;

	assert.strictEqual(aliceSecret.toString('hex'), bobSecret.toString('hex'),"These secrets are not match");

	//Testing Diffie Hellman algorithm
	// console.log("Alice secret key");
	// console.log(user.u1);
	// console.log("Alice public key");
	// console.log(user.u2);
	// var sharedPrime = 11;//same prime number
	// var sharedBase  = 2;//same base number
	// var aliceSecret = user.u1;//not greater than prime    
	// //bob 
 // 	var bobSecret 	= Math.floor(Math.random() * 11);//not greater than prime    
 // 	console.log("Bob secrets key");
 // 	console.log(bobSecret);
 // 	//bob
 // 	var alicePublic = user.u2; 

 // 	var bobPublic = Math.pow(sharedBase , bobSecret) % sharedPrime;
 // 	console.log("Bob public key");   
 // 	console.log(bobPublic);

 // 	var aliceSharedSecret = Math.pow(bobPublic , aliceSecret) % sharedPrime;
 // 	console.log("aliceSharedSecret");
 // 	console.log(aliceSharedSecret);

 // 	var bobSharedSecret = Math.pow(alicePublic, bobSecret) % sharedPrime;
 // 	console.log("bobSharedSecret");
 // 	console.log(bobSharedSecret);
	
	cb(null,{aliceSharedSecret:aliceSharedSecret,bobSharedSecret:bobSharedSecret});
}

// exports.requestUser = function(user, cb)
// {
// 	var q = ""
// 	db.getConnection(function(err, connection){
// 		connection.query(q, [id,id], function(err, result){
// 			connection.release();
// 			if(!err){
// 				cb(null, {message : "success"});
// 			}else{
// 				cb(err, null);
// 			}
// 		});		
// 	});
// }